
function about() {

  return (
    <div>about</div>
  )
}

export default about