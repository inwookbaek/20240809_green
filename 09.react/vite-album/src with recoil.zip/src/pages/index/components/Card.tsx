import { CardDTO } from '../types/card'
import styles from './Card.module.scss'

interface Props {
  data: CardDTO
  handleDiglog: (eventValue: boolean) => void 
  handleSetData: (eventValue: CardDTO) => void 
}

function Card({ data, handleDiglog, handleSetData }: Props ) {

  const openDialog = () => {
    console.log('함수호출')
    handleDiglog(true);
    handleSetData(data);
  }

  return (
    <div className={styles.card} onClick={openDialog}>
      <img src={data.urls.small} alt={data.alt_description} className={styles.card__image} />
    </div>
  )
}

export default Card;